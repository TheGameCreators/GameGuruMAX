// DBOEffects Functions Header
#ifndef _DBOEFFECTS_H_
#define _DBOEFFECTS_H_

#define WIN32_LEAN_AND_MEAN 
#include <windows.h>
#include "directx-macros.h"
#include "..\global.h"
#include "DBOFormat.h"

class cExternalEffect : public cSpecialEffect {};

#endif _DBOEFFECTS_H_

